package com.veilborn.island.registry;

import com.veilborn.island.VeilbornMod;
import com.veilborn.island.item.BandageItem;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModItems {
    private ModItems() {}

    public static final Item WOOD = register("wood", new Item(new Item.Settings()));
    public static final Item STICK = register("stick", new Item(new Item.Settings()));
    public static final Item STONE = register("stone", new Item(new Item.Settings()));
    public static final Item IRON = register("iron", new Item(new Item.Settings()));
    public static final Item OIL = register("oil", new Item(new Item.Settings()));
    public static final Item BLADE = register("blade", new Item(new Item.Settings()));
    public static final Item LEATHER = register("leather", new Item(new Item.Settings()));
    public static final Item STRING = register("string", new Item(new Item.Settings()));
    public static final Item COBWEB = register("cobweb", new Item(new Item.Settings()));
    public static final Item ANCIENT_CRYSTAL = register("ancient_crystal", new Item(new Item.Settings()));
    public static final Item CLOTH = register("cloth", new Item(new Item.Settings()));

    public static final Item COCONUT = register("coconut", new Item(new Item.Settings().food(new FoodComponent.Builder().hunger(4).saturationModifier(0.4f).build())));
    public static final Item BERRY = register("berry", new Item(new Item.Settings().food(new FoodComponent.Builder().hunger(2).saturationModifier(0.25f).build())));
    public static final Item ANIMAL_MEAT = register("animal_meat", new Item(new Item.Settings().food(new FoodComponent.Builder().hunger(6).saturationModifier(0.6f).build())));
    public static final Item MEDICINE_HERBS = register("medicine_herbs", new Item(new Item.Settings().food(new FoodComponent.Builder().hunger(2).saturationModifier(1.2f).build())));
    public static final Item HELICOPTER_KEY = register("helicopter_key", new Item(new Item.Settings().maxCount(1)));
    public static final Item ISLAND_MAP = register("island_map", new Item(new Item.Settings().maxCount(1)));

    public static final Item BANDAGE = register("bandage", new BandageItem(new Item.Settings().maxCount(16)));
    public static final Item STONE_SWORD = register("stone_sword", new SwordItem(ToolMaterials.STONE, 3, -2.4f, new Item.Settings()));
    public static final Item IRON_SWORD = register("iron_sword", new SwordItem(ToolMaterials.IRON, 3, -2.4f, new Item.Settings()));
    public static final Item STEEL_BLADE = register("steel_blade", new SwordItem(ToolMaterials.IRON, 4, -2.2f, new Item.Settings()));
    public static final Item WOODEN_SHIELD = register("wooden_shield", new ShieldItem(new Item.Settings().maxDamage(336)));
    public static final Item BOW = register("bow", new BowItem(new Item.Settings().maxDamage(384)));
    public static final Item FIRE_ARROWS = register("fire_arrows", new Item(new Item.Settings().maxCount(64)));
    public static final Item STONE_PICKAXE = register("stone_pickaxe", new PickaxeItem(ToolMaterials.STONE, 1, -2.8f, new Item.Settings()));
    public static final Item STONE_AXE = register("stone_axe", new AxeItem(ToolMaterials.STONE, 5.5f, -3.0f, new Item.Settings()));
    public static final Item TORCH = register("torch", new Item(new Item.Settings()));
    public static final Item CAMPFIRE = register("campfire", new Item(new Item.Settings().maxCount(16)));

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(entries -> {
            entries.add(WOOD);
            entries.add(STICK);
            entries.add(STONE);
            entries.add(IRON);
            entries.add(OIL);
            entries.add(BLADE);
            entries.add(LEATHER);
            entries.add(STRING);
            entries.add(COBWEB);
            entries.add(ANCIENT_CRYSTAL);
            entries.add(CLOTH);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FOOD_AND_DRINK).register(entries -> {
            entries.add(COCONUT);
            entries.add(BERRY);
            entries.add(ANIMAL_MEAT);
            entries.add(MEDICINE_HERBS);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            entries.add(HELICOPTER_KEY);
            entries.add(STONE_SWORD);
            entries.add(IRON_SWORD);
            entries.add(STEEL_BLADE);
            entries.add(WOODEN_SHIELD);
            entries.add(BOW);
            entries.add(FIRE_ARROWS);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            entries.add(STONE_PICKAXE);
            entries.add(STONE_AXE);
            entries.add(TORCH);
            entries.add(CAMPFIRE);
            entries.add(BANDAGE);
            entries.add(ISLAND_MAP);
        });
    }

    private static Item register(String path, Item item) {
        return Registry.register(Registries.ITEM, new Identifier(VeilbornMod.MOD_ID, path), item);
    }
}
