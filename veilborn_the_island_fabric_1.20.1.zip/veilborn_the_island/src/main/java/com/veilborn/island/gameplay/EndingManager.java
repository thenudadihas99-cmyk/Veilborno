package com.veilborn.island.gameplay;

import com.veilborn.island.PlayerProfile;
import com.veilborn.island.VeilbornState;
import com.veilborn.island.registry.ModSounds;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.GameMode;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

public final class EndingManager {
    private EndingManager() {}

    private static final Map<UUID, Integer> ENDING_TICKS = new HashMap<>();

    public static void startEnding(ServerPlayerEntity player, VeilbornState state) {
        if (state.endingStarted) return;
        state.endingStarted = true;
        state.markDirty();

        PlayerProfile profile = state.getProfile(player.getUuid());
        if (profile.missionIndex < 56) {
            profile.missionIndex = 56;
        }
        profile.dirty = true;

        ENDING_TICKS.put(player.getUuid(), 0);
        player.changeGameMode(GameMode.SPECTATOR);
        player.teleport(player.getServerWorld(),
                com.veilborn.island.Landmarks.HELICOPTER_SITE.getX() + 0.5,
                com.veilborn.island.Landmarks.HELICOPTER_SITE.getY() + 20.0,
                com.veilborn.island.Landmarks.HELICOPTER_SITE.getZ() + 0.5,
                90.0f, 0.0f);
        player.sendMessage(Text.literal("Helicopter engines are roaring...").formatted(Formatting.GOLD), false);
        player.getWorld().playSound(null, player.getBlockPos(), ModSounds.BOSS_MUSIC, net.minecraft.sound.SoundCategory.MUSIC, 1.5f, 1.0f);
        MissionManager.sync(player, state);
    }

    public static boolean isEndingRunning(ServerPlayerEntity player) {
        return ENDING_TICKS.containsKey(player.getUuid());
    }

    public static void tickWorld(net.minecraft.server.world.ServerWorld world, VeilbornState state) {
        Iterator<Map.Entry<UUID, Integer>> iterator = ENDING_TICKS.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Integer> entry = iterator.next();
            ServerPlayerEntity player = world.getServer().getPlayerManager().getPlayer(entry.getKey());
            if (player == null) {
                iterator.remove();
                continue;
            }

            int tick = entry.getValue() + 1;
            entry.setValue(tick);

            if (tick == 1) {
                player.sendMessage(Text.literal("The island fades behind the fog.").formatted(Formatting.GRAY), false);
            } else if (tick == 120) {
                player.sendMessage(Text.literal("Credits...").formatted(Formatting.GOLD), false);
                player.getWorld().playSound(null, player.getBlockPos(), ModSounds.LAB_MUSIC, net.minecraft.sound.SoundCategory.MUSIC, 1.0f, 0.9f);
            } else if (tick >= 240) {
                PlayerProfile profile = state.getProfile(player.getUuid());
                MissionManager.completeMission(player, state, 56, "Helicopter startup complete.");
                MissionManager.completeMission(player, state, 57, "Take off achieved.");
                MissionManager.completeMission(player, state, 58, "Final escape path secured.");
                MissionManager.completeMission(player, state, 59, "Veilborn has been escaped.");

                player.changeGameMode(GameMode.SURVIVAL);
                player.teleport(world,
                        com.veilborn.island.Landmarks.SAFE_HOUSE.getX() + 0.5,
                        com.veilborn.island.Landmarks.SAFE_HOUSE.getY() + 2.0,
                        com.veilborn.island.Landmarks.SAFE_HOUSE.getZ() + 0.5,
                        player.getYaw(), 0.0f);
                player.sendMessage(Text.literal("Cinematic credits complete.").formatted(Formatting.GRAY), false);

                profile.creditsSeen = true;
                profile.dirty = true;
                MissionManager.sync(player, state);
                state.markDirty();
                iterator.remove();
            }
        }
    }

    public static void onBossDefeated(ServerPlayerEntity player, VeilbornState state) {
        state.bossDefeated = true;
        state.markDirty();
        player.sendMessage(Text.literal("The Giant Zombie has fallen.").formatted(Formatting.DARK_RED), false);
        MissionManager.completeMission(player, state, 47, "The boss has been defeated.");
        MissionManager.sync(player, state);
    }
}
