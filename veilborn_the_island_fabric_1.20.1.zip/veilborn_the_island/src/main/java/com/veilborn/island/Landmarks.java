package com.veilborn.island;

import net.minecraft.util.math.BlockPos;

public final class Landmarks {
    private Landmarks() {}

    public static final BlockPos PIER = new BlockPos(160, 64, 0);
    public static final BlockPos ABANDONED_HOUSE = new BlockPos(-110, 66, 120);
    public static final BlockPos SAFE_HOUSE = new BlockPos(-30, 66, -30);
    public static final BlockPos LABORATORY = new BlockPos(0, 68, -140);
    public static final BlockPos WATCH_TOWER_NORTH = new BlockPos(0, 90, -100);
    public static final BlockPos WATCH_TOWER_SOUTH = new BlockPos(0, 90, 100);
    public static final BlockPos WATCH_TOWER_EAST = new BlockPos(100, 90, 0);
    public static final BlockPos WATCH_TOWER_WEST = new BlockPos(-100, 90, 0);
    public static final BlockPos SHIPWRECK = new BlockPos(-170, 62, -20);
    public static final BlockPos HELICOPTER_SITE = new BlockPos(30, 70, 30);
    public static final BlockPos ZOMBIE_CAMP = new BlockPos(130, 66, -90);
    public static final BlockPos SECRET_CAVE = new BlockPos(70, 54, -130);
    public static final BlockPos BOSS_ARENA = new BlockPos(90, 66, -70);
}
