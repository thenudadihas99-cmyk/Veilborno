package com.veilborn.island.entity;

import com.veilborn.island.VeilbornMod;
import com.veilborn.island.VeilbornState;
import com.veilborn.island.registry.ModItems;
import com.veilborn.island.registry.ModSounds;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

public class GiantZombieEntity extends ZombieEntity {
    private int smashCooldown = 0;

    public GiantZombieEntity(EntityType<? extends ZombieEntity> entityType, World world) {
        super(entityType, world);
    }

    public static DefaultAttributeContainer.Builder createBossAttributes() {
        return ZombieEntity.createZombieAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 5000.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 28.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 80.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.0, true));
        this.goalSelector.add(6, new net.minecraft.entity.ai.goal.WanderAroundFarGoal(this, 0.9));
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, LivingEntity.class, true));
        this.targetSelector.add(2, new RevengeGoal(this));
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.getWorld().isClient) {
            if (smashCooldown > 0) smashCooldown--;
            if (this.getTarget() != null && this.squaredDistanceTo(this.getTarget()) < 25 && smashCooldown == 0) {
                smashCooldown = 60;
                Box box = this.getBoundingBox().expand(7.0);
                for (LivingEntity entity : this.getWorld().getEntitiesByClass(LivingEntity.class, box, e -> e != this)) {
                    entity.damage(this.getDamageSources().mobAttack(this), 18.0f);
                    entity.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 60, 0));
                }
                this.getWorld().playSound(null, this.getBlockPos(), ModSounds.BOSS_MUSIC, SoundCategory.HOSTILE, 2.0f, 0.75f);
                this.getWorld().addParticle(ParticleTypes.EXPLOSION_EMITTER, this.getX(), this.getY(), this.getZ(), 0.0, 0.0, 0.0);
            }
        }
    }

@Override
public void onDeath(DamageSource source) {
    super.onDeath(source);
    if (!this.getWorld().isClient && source.getAttacker() instanceof net.minecraft.server.network.ServerPlayerEntity player) {
        com.veilborn.island.VeilbornState state = com.veilborn.island.VeilbornState.get(player.getServerWorld());
        com.veilborn.island.gameplay.EndingManager.onBossDefeated(player, state);
    }
}

    @Override
    protected void dropEquipment(DamageSource source, int looting, boolean causedByPlayer) {
        super.dropEquipment(source, looting, causedByPlayer);
        this.dropStack(new ItemStack(ModItems.HELICOPTER_KEY, 1));
        this.dropStack(new ItemStack(ModItems.IRON, 8));
        this.dropStack(new ItemStack(ModItems.BLADE, 2));
    }
}
