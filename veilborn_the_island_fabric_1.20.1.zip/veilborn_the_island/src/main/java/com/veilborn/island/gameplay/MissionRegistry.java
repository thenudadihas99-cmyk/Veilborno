package com.veilborn.island.gameplay;

import com.veilborn.island.Landmarks;
import com.veilborn.island.VeilbornMod;
import com.veilborn.island.VeilbornState;
import com.veilborn.island.registry.ModEntities;
import com.veilborn.island.registry.ModItems;
import net.minecraft.entity.EntityType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.GameMode;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.stat.Stats;

import java.util.ArrayList;
import java.util.List;

public final class MissionRegistry {
    private MissionRegistry() {}

    public static final List<MissionDefinition> MISSIONS = create();

    private static List<MissionDefinition> create() {
        List<MissionDefinition> list = new ArrayList<>();

        list.add(new MissionDefinition("M01", "Pier Breakout", "Walk 500 blocks from the pier.", 1,
                (player, state) -> nearDistance(player, Landmarks.PIER, 500.0) ? 1 : 0,
                rewardItem(ModItems.ISLAND_MAP, 1, "Map unlocked.")));

        list.add(new MissionDefinition("M02", "Shelter Found", "Find the abandoned house.", 1,
                (player, state) -> near(player, Landmarks.ABANDONED_HOUSE, 18.0) ? 1 : 0,
                rewardItem(ModItems.BANDAGE, 2, "Save point unlocked.")));

        list.add(new MissionDefinition("M03", "Gathering Basics", "Collect 20 Wood and 10 Stone.", 1,
                (player, state) -> (count(player, ModItems.WOOD) >= 20 && count(player, ModItems.STONE) >= 10) ? 1 : 0,
                rewardItem(ModItems.STICK, 8, "Inventory tutorial unlocked.")));

        list.add(new MissionDefinition("M04", "Craft a Pickaxe", "Craft a Stone Pickaxe.", 1,
                (player, state) -> crafted(player, ModItems.STONE_PICKAXE) >= 1 ? 1 : 0,
                rewardItem(ModItems.TORCH, 16, "Mining route marked.")));

        list.add(new MissionDefinition("M05", "First Food Cache", "Collect 8 food items.", 8,
                (player, state) -> Math.min(8, count(player, ModItems.COCONUT) + count(player, ModItems.BERRY) + count(player, ModItems.ANIMAL_MEAT)),
                rewardItem(ModItems.ANIMAL_MEAT, 4, "Food storage marked.")));

        list.add(new MissionDefinition("M06", "Enter the Cave", "Reach the cave system.", 1,
                (player, state) -> near(player, Landmarks.SECRET_CAVE, 24.0) ? 1 : 0,
                rewardItem(ModItems.ANCIENT_CRYSTAL, 1, "Cave systems mapped.")));

        list.add(new MissionDefinition("M07", "First Relic", "Recover an Ancient Crystal.", 1,
                (player, state) -> count(player, ModItems.ANCIENT_CRYSTAL) >= 1 ? 1 : 0,
                rewardItem(ModItems.BANDAGE, 2, "Relic chamber unlocked.")));

        list.add(new MissionDefinition("M08", "Camp Tools", "Craft a Torch or Campfire.", 1,
                (player, state) -> crafted(player, ModItems.TORCH) >= 1 || crafted(player, ModItems.CAMPFIRE) >= 1 ? 1 : 0,
                rewardItem(ModItems.WOOD, 16, "Camping route unlocked.")));

        list.add(new MissionDefinition("M09", "Basic Treatment", "Craft or obtain a Bandage.", 1,
                (player, state) -> count(player, ModItems.BANDAGE) >= 1 ? 1 : 0,
                rewardItem(ModItems.MEDICINE_HERBS, 4, "Medical herbs revealed.")));

        list.add(new MissionDefinition("M10", "First Night", "Survive 1 full day.", 1,
                (player, state) -> state.worldDayCounter > 1 ? 1 : 0,
                rewardItem(ModItems.CLOTH, 4, "Night survival recorded.")));

        list.add(new MissionDefinition("M11", "North Tower", "Reach the north watch tower.", 1,
                (player, state) -> near(player, Landmarks.WATCH_TOWER_NORTH, 12.0) ? 1 : 0,
                rewardItem(ModItems.STRING, 8, "Tower sightlines unlocked.")));

        list.add(new MissionDefinition("M12", "South Tower", "Reach the south watch tower.", 1,
                (player, state) -> near(player, Landmarks.WATCH_TOWER_SOUTH, 12.0) ? 1 : 0,
                rewardItem(ModItems.STRING, 8, "Secondary tower route unlocked.")));

        list.add(new MissionDefinition("M13", "Ant Hunt", "Kill 10 Ants.", 10,
                (player, state) -> Math.min(10, player.getStatHandler().getStat(Stats.KILLED.getOrCreateStat(ModEntities.ANT))),
                rewardItem(ModItems.STRING, 10, "Ant nests marked.")));

        list.add(new MissionDefinition("M14", "Zombie Cull", "Kill 5 Normal Zombies.", 5,
                (player, state) -> Math.min(5, player.getStatHandler().getStat(Stats.KILLED.getOrCreateStat(ModEntities.NORMAL_ZOMBIE))),
                rewardItem(ModItems.CLOTH, 4, "Zombie threat recorded.")));

        list.add(new MissionDefinition("M15", "Cloth Supply", "Collect 6 Cloth.", 6,
                (player, state) -> Math.min(6, count(player, ModItems.CLOTH)),
                rewardItem(ModItems.BANDAGE, 3, "Cloth supply secured.")));

        list.add(new MissionDefinition("M16", "Laboratory Edge", "Reach the old laboratory.", 1,
                (player, state) -> near(player, Landmarks.LABORATORY, 18.0) ? 1 : 0,
                rewardItem(ModItems.OIL, 2, "Lab access granted.")));

        list.add(new MissionDefinition("M17", "Fuel Salvage", "Collect 4 Oil.", 4,
                (player, state) -> Math.min(4, count(player, ModItems.OIL)),
                rewardItem(ModItems.IRON, 4, "Fuel reserve marked.")));

        list.add(new MissionDefinition("M18", "Metal Work", "Collect 5 Iron.", 5,
                (player, state) -> Math.min(5, count(player, ModItems.IRON)),
                rewardItem(ModItems.STEEL_BLADE, 1, "Workshop unlocked.")));

        list.add(new MissionDefinition("M19", "Crash Site", "Reach the helicopter crash site.", 1,
                (player, state) -> near(player, Landmarks.HELICOPTER_SITE, 18.0) ? 1 : 0,
                rewardItem(ModItems.OIL, 4, "Crash site map updated.")));

        list.add(new MissionDefinition("M20", "Iron Blade", "Craft an Iron Sword.", 1,
                (player, state) -> crafted(player, ModItems.IRON_SWORD) >= 1 || count(player, ModItems.IRON_SWORD) >= 1 ? 1 : 0,
                rewardItem(ModItems.IRON, 4, "Weapon upgrade unlocked.")));

        list.add(new MissionDefinition("M21", "Shield Wall", "Craft a Wooden Shield.", 1,
                (player, state) -> count(player, ModItems.WOODEN_SHIELD) >= 1 ? 1 : 0,
                rewardItem(ModItems.WOOD, 12, "Defense tutorial unlocked.")));

        list.add(new MissionDefinition("M22", "Dark Forest", "Enter the dark forest region.", 1,
                (player, state) -> player.getX() < -60 && player.getZ() > 80 ? 1 : 0,
                rewardItem(ModItems.COBWEB, 4, "Forest threat marked.")));

        list.add(new MissionDefinition("M23", "Shadow Sample", "Kill a Shadow Zombie.", 1,
                (player, state) -> Math.min(1, player.getStatHandler().getStat(Stats.KILLED.getOrCreateStat(ModEntities.SHADOW_ZOMBIE))),
                rewardItem(ModItems.OIL, 2, "Shadow biology captured.")));

        list.add(new MissionDefinition("M24", "Web Harvest", "Collect 8 Cobweb.", 8,
                (player, state) -> Math.min(8, count(player, ModItems.COBWEB)),
                rewardItem(ModItems.STRING, 12, "Spider trail found.")));

        list.add(new MissionDefinition("M25", "Ten Days", "Survive 10 days.", 10,
                (player, state) -> (int) Math.min(10, Math.max(0, state.worldDayCounter - 1)),
                rewardItem(ModItems.BANDAGE, 4, "Long-term survival marked.")));

        list.add(new MissionDefinition("M26", "Wreck Hunt", "Reach the shipwreck.", 1,
                (player, state) -> near(player, Landmarks.SHIPWRECK, 18.0) ? 1 : 0,
                rewardItem(ModItems.LEATHER, 4, "Wreckage recorded.")));

        list.add(new MissionDefinition("M27", "Leather Stash", "Collect 6 Leather.", 6,
                (player, state) -> Math.min(6, count(player, ModItems.LEATHER)),
                rewardItem(ModItems.STRING, 8, "Sewing supplies found.")));

        list.add(new MissionDefinition("M28", "Eastern Tower", "Reach the east watch tower.", 1,
                (player, state) -> near(player, Landmarks.WATCH_TOWER_EAST, 12.0) ? 1 : 0,
                rewardItem(ModItems.TORCH, 16, "Eastern range mapped.")));

        list.add(new MissionDefinition("M29", "Night Pressure", "Survive a midnight horde.", 1,
                (player, state) -> state.lastHordeDay >= 1 ? 1 : 0,
                rewardItem(ModItems.BANDAGE, 2, "Horde report logged.")));

        list.add(new MissionDefinition("M30", "Hidden Depths", "Discover the secret cave.", 1,
                (player, state) -> near(player, Landmarks.SECRET_CAVE, 20.0) ? 1 : 0,
                rewardItem(ModItems.ANCIENT_CRYSTAL, 1, "Secret cave unlocked.")));

        list.add(new MissionDefinition("M31", "Second Relic", "Collect 2 Ancient Crystals.", 2,
                (player, state) -> Math.min(2, count(player, ModItems.ANCIENT_CRYSTAL)),
                rewardItem(ModItems.MEDICINE_HERBS, 8, "Relic resonance detected.")));

        list.add(new MissionDefinition("M32", "Night Hunter", "Kill a Shadow Spider.", 1,
                (player, state) -> Math.min(1, player.getStatHandler().getStat(Stats.KILLED.getOrCreateStat(ModEntities.SHADOW_SPIDER))),
                rewardItem(ModItems.STRING, 20, "Spider threat neutralized.")));

        list.add(new MissionDefinition("M33", "Archer", "Craft a Bow.", 1,
                (player, state) -> crafted(player, ModItems.BOW) >= 1 || count(player, ModItems.BOW) >= 1 ? 1 : 0,
                rewardItem(ModItems.FIRE_ARROWS, 16, "Ranged combat unlocked.")));

        list.add(new MissionDefinition("M34", "Fire Arrows", "Craft 16 Fire Arrows.", 16,
                (player, state) -> Math.min(16, count(player, ModItems.FIRE_ARROWS)),
                rewardItem(ModItems.OIL, 4, "Incendiary ammo ready.")));

        list.add(new MissionDefinition("M35", "Steel Work", "Craft a Steel Blade.", 1,
                (player, state) -> count(player, ModItems.STEEL_BLADE) >= 1 || crafted(player, ModItems.STEEL_BLADE) >= 1 ? 1 : 0,
                rewardItem(ModItems.IRON, 6, "Steel foundry unlocked.")));

        list.add(new MissionDefinition("M36", "Medic", "Collect 10 Medicine Herbs.", 10,
                (player, state) -> Math.min(10, count(player, ModItems.MEDICINE_HERBS)),
                rewardItem(ModItems.BANDAGE, 4, "Medical camp marked.")));

        list.add(new MissionDefinition("M37", "Field Care", "Craft 3 Bandages.", 3,
                (player, state) -> Math.min(3, crafted(player, ModItems.BANDAGE)),
                rewardItem(ModItems.CLOTH, 8, "Field clinic unlocked.")));

        list.add(new MissionDefinition("M38", "Twenty Days", "Survive 20 days.", 20,
                (player, state) -> (int) Math.min(20, Math.max(0, state.worldDayCounter - 1)),
                rewardItem(ModItems.ANCIENT_CRYSTAL, 1, "Long-term survival complete.")));

        list.add(new MissionDefinition("M39", "Camp Raid", "Reach the zombie camp.", 1,
                (player, state) -> near(player, Landmarks.ZOMBIE_CAMP, 18.0) ? 1 : 0,
                rewardItem(ModItems.CLOTH, 6, "Camp intel obtained.")));

        list.add(new MissionDefinition("M40", "Wood Stockpile", "Collect 100 Wood.", 100,
                (player, state) -> Math.min(100, count(player, ModItems.WOOD)),
                rewardItem(ModItems.WOOD, 24, "Stockpile secured.")));

        list.add(new MissionDefinition("M41", "Stone Stockpile", "Collect 80 Stone.", 80,
                (player, state) -> Math.min(80, count(player, ModItems.STONE)),
                rewardItem(ModItems.STONE_PICKAXE, 1, "Mining route improved.")));

        list.add(new MissionDefinition("M42", "Signal Repair", "Reach the laboratory console.", 1,
                (player, state) -> near(player, Landmarks.LABORATORY, 12.0) ? 1 : 0,
                rewardItem(ModItems.OIL, 6, "Signal panel calibrated.")));

        list.add(new MissionDefinition("M43", "Map Complete", "Visit the pier again with a map.", 1,
                (player, state) -> near(player, Landmarks.PIER, 22.0) ? 1 : 0,
                rewardItem(ModItems.ISLAND_MAP, 1, "Map of Veilborn completed.")));

        list.add(new MissionDefinition("M44", "Twenty-Five Days", "Survive 25 days.", 25,
                (player, state) -> (int) Math.min(25, Math.max(0, state.worldDayCounter - 1)),
                rewardItem(ModItems.BANDAGE, 6, "Late survival recorded.")));

        list.add(new MissionDefinition("M45", "Slaughter Run", "Kill 20 Normal Zombies.", 20,
                (player, state) -> Math.min(20, player.getStatHandler().getStat(Stats.KILLED.getOrCreateStat(ModEntities.NORMAL_ZOMBIE))),
                rewardItem(ModItems.CLOTH, 10, "Zombie population reduced.")));

        list.add(new MissionDefinition("M46", "Shadow War", "Kill 10 Shadow Zombies.", 10,
                (player, state) -> Math.min(10, player.getStatHandler().getStat(Stats.KILLED.getOrCreateStat(ModEntities.SHADOW_ZOMBIE))),
                rewardItem(ModItems.OIL, 8, "Shadow warfare unlocked.")));

        list.add(new MissionDefinition("M47", "Boss Signal", "Prepare for the Giant Zombie.", 1,
                (player, state) -> state.bossSpawned || state.bossDefeated ? 1 : 0,
                rewardItem(ModItems.IRON, 10, "Boss arena active.")));

        list.add(new MissionDefinition("M48", "Boss Fight", "Defeat the Giant Zombie.", 1,
                (player, state) -> state.bossDefeated ? 1 : 0,
                rewardItem(ModItems.HELICOPTER_KEY, 1, "Helicopter Key recovered.")));

        list.add(new MissionDefinition("M49", "Key Recovery", "Obtain the Helicopter Key.", 1,
                (player, state) -> (count(player, ModItems.HELICOPTER_KEY) >= 1 || state.bossDefeated) ? 1 : 0,
                rewardItem(ModItems.OIL, 4, "Escape route unlocked.")));

        list.add(new MissionDefinition("M50", "Rotor Repair", "Collect 4 Iron and 4 Oil.", 4,
                (player, state) -> Math.min(4, Math.min(count(player, ModItems.IRON), count(player, ModItems.OIL))),
                rewardItem(ModItems.IRON_SWORD, 1, "Rotor repair complete.")));

        list.add(new MissionDefinition("M51", "Fuel Line", "Collect 10 Oil.", 10,
                (player, state) -> Math.min(10, count(player, ModItems.OIL)),
                rewardItem(ModItems.BANDAGE, 4, "Fuel line ready.")));

        list.add(new MissionDefinition("M52", "Control Panel", "Collect 8 Cloth and 8 String.", 8,
                (player, state) -> Math.min(8, Math.min(count(player, ModItems.CLOTH), count(player, ModItems.STRING))),
                rewardItem(ModItems.WOODEN_SHIELD, 1, "Control panel stabilized.")));

        list.add(new MissionDefinition("M53", "Final Supplies", "Collect 12 Bandages or Medicine Herbs.", 12,
                (player, state) -> Math.min(12, count(player, ModItems.BANDAGE) + count(player, ModItems.MEDICINE_HERBS)),
                rewardItem(ModItems.BANDAGE, 4, "Final supplies packed.")));

        list.add(new MissionDefinition("M54", "Return to Crash Site", "Reach the helicopter crash site again.", 1,
                (player, state) -> near(player, Landmarks.HELICOPTER_SITE, 18.0) ? 1 : 0,
                rewardItem(ModItems.STEEL_BLADE, 1, "Final approach marked.")));

        list.add(new MissionDefinition("M55", "Defend the Site", "Stand against the island's night surge.", 1,
                (player, state) -> state.lastHordeDay >= 1 ? 1 : 0,
                rewardItem(ModItems.TORCH, 16, "Defense perimeter improved.")));

        list.add(new MissionDefinition("M56", "Repair Check", "Have the key and reach the console.", 1,
                (player, state) -> near(player, Landmarks.HELICOPTER_SITE, 8.0) && count(player, ModItems.HELICOPTER_KEY) >= 1 ? 1 : 0,
                rewardItem(ModItems.OIL, 4, "Repair verified.")));

        list.add(new MissionDefinition("M57", "Startup", "Use the helicopter console.", 1,
                (player, state) -> state.endingStarted ? 1 : 0,
                rewardItem(ModItems.BANDAGE, 1, "Launch sequence initiated.")));

        list.add(new MissionDefinition("M58", "Boarding", "Reach the helicopter launch sequence.", 1,
                (player, state) -> state.endingStarted ? 1 : 0,
                rewardItem(ModItems.ISLAND_MAP, 1, "Boarding checklist complete.")));

        list.add(new MissionDefinition("M59", "Take Off", "Escape the island by helicopter.", 1,
                (player, state) -> (state.bossDefeated && state.endingStarted) ? 1 : 0,
                rewardItem(ModItems.ANCIENT_CRYSTAL, 2, "Escape route complete.")));

        list.add(new MissionDefinition("M60", "Credits", "Watch the end credits.", 1,
                (player, state) -> state.bossDefeated && state.endingStarted ? 1 : 0,
                rewardMessage("Veilborn is conquered.", "You survived the island.")));

        return list;
    }

    private static MissionReward rewardItem(Item item, int count, String message) {
        return (player, state) -> {
            player.giveItemStack(new ItemStack(item, count));
            player.sendMessage(Text.literal(message).formatted(Formatting.GREEN), false);
            player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 0.8f, 1.2f);
        };
    }

    private static MissionReward rewardMessage(String title, String message) {
        return (player, state) -> {
            player.sendMessage(Text.literal(title).formatted(Formatting.GOLD), false);
            player.sendMessage(Text.literal(message).formatted(Formatting.GRAY), false);
            player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 0.8f, 1.3f);
        };
    }

    public static MissionDefinition mission(int index) {
        if (index < 0 || index >= MISSIONS.size()) return MISSIONS.get(0);
        return MISSIONS.get(index);
    }

    private static int count(ServerPlayerEntity player, Item item) {
        return player.getInventory().count(item);
    }

    private static int crafted(ServerPlayerEntity player, Item item) {
        return player.getStatHandler().getStat(Stats.CRAFTED.getOrCreateStat(item));
    }

    private static boolean near(ServerPlayerEntity player, BlockPos pos, double radius) {
        return player.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= radius * radius;
    }

    private static boolean nearDistance(ServerPlayerEntity player, BlockPos pos, double distance) {
        return player.getPos().distanceTo(net.minecraft.util.math.Vec3d.ofCenter(pos)) >= distance;
    }
}
