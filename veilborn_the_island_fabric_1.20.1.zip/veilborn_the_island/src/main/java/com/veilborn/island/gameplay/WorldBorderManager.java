package com.veilborn.island.gameplay;

import com.veilborn.island.VeilbornState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.Vec3d;

public final class WorldBorderManager {
    private WorldBorderManager() {}

    public static final double BORDER = 240.0;

    public static void tickWorld(ServerWorld world, VeilbornState state) {
        for (PlayerEntity player : world.getPlayers()) {
            double x = player.getX();
            double z = player.getZ();
            boolean wrapped = false;
            double nx = x;
            double nz = z;
            if (x > BORDER) {
                nx = -BORDER + (x - BORDER);
                wrapped = true;
            } else if (x < -BORDER) {
                nx = BORDER + (x + BORDER);
                wrapped = true;
            }
            if (z > BORDER) {
                nz = -BORDER + (z - BORDER);
                wrapped = true;
            } else if (z < -BORDER) {
                nz = BORDER + (z + BORDER);
                wrapped = true;
            }
            if (wrapped) {
                player.teleport((ServerWorld) player.getWorld(), nx, player.getY(), nz, player.getYaw(), player.getPitch());
                player.setVelocity(player.getVelocity());
                player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 0.6f, 1.8f);
            }
        }
    }
}
