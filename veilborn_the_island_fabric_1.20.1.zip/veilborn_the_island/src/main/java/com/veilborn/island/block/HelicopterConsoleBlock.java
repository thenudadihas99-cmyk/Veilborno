package com.veilborn.island.block;

import com.veilborn.island.VeilbornState;
import com.veilborn.island.gameplay.EndingManager;
import com.veilborn.island.gameplay.MissionManager;
import com.veilborn.island.registry.ModItems;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class HelicopterConsoleBlock extends Block {
    public HelicopterConsoleBlock(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, net.minecraft.util.hit.BlockHitResult hit) {
        if (world.isClient) return ActionResult.SUCCESS;

        VeilbornState veilbornState = VeilbornState.get((net.minecraft.server.world.ServerWorld) world);

        if (player.getInventory().count(ModItems.HELICOPTER_KEY) < 1) {
            player.sendMessage(Text.literal("A helicopter key is required to start the engine."), false);
            world.playSound(null, pos, SoundEvents.BLOCK_CHEST_LOCKED, SoundCategory.BLOCKS, 0.8f, 0.8f);
            return ActionResult.CONSUME;
        }

        if (veilbornState.getProfile(player.getUuid()).missionIndex < 56) {
            player.sendMessage(Text.literal("The helicopter systems are still offline. Keep surviving."), false);
            world.playSound(null, pos, SoundEvents.BLOCK_ANVIL_PLACE, SoundCategory.BLOCKS, 0.7f, 0.6f);
            return ActionResult.CONSUME;
        }

        removeOne(player, ModItems.HELICOPTER_KEY);
        MissionManager.completeMission((net.minecraft.server.network.ServerPlayerEntity) player, veilbornState, 56, "Helicopter repairs confirmed.");
        EndingManager.startEnding((net.minecraft.server.network.ServerPlayerEntity) player, veilbornState);
        world.playSound(null, pos, SoundEvents.ITEM_FIRECHARGE_USE, SoundCategory.BLOCKS, 1.0f, 0.7f);
        return ActionResult.CONSUME;
    }

    private static void removeOne(PlayerEntity player, net.minecraft.item.Item item) {
        for (int i = 0; i < player.getInventory().size(); i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.isOf(item)) {
                stack.decrement(1);
                player.getInventory().markDirty();
                return;
            }
        }
    }
}
