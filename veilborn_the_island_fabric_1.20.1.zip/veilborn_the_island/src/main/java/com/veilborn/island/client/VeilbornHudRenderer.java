package com.veilborn.island.client;

import com.veilborn.island.Landmarks;
import com.veilborn.island.VeilbornMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class VeilbornHudRenderer {
    private VeilbornHudRenderer() {}

    public static void render(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        int width = client.getWindow().getScaledWidth();
        int height = client.getWindow().getScaledHeight();
        TextRenderer text = client.textRenderer;

        // Crosshair
        int cx = width / 2;
        int cy = height / 2;
        context.fill(cx - 6, cy, cx + 6, cy + 1, 0xFFFFFFFF);
        context.fill(cx, cy - 6, cx + 1, cy + 6, 0xFFFFFFFF);

        // Red damage flash
        if (client.player.hurtTime > 0) {
            int alpha = Math.min(120, client.player.hurtTime * 16);
            context.fill(0, 0, width, height, (alpha << 24) | 0xAA0000);
        }

        // Mission tracker
        int x = 8;
        int y = 8;
        context.fill(x - 4, y - 4, x + 260, y + 52, 0x88000000);
        context.drawTextWithShadow(text, Text.literal("VEILBORN: THE ISLAND").formatted(Formatting.GOLD), x, y, 0xFFFFFF);
        context.drawTextWithShadow(text, Text.literal("Day " + ClientState.day + "  |  Stamina " + ClientState.stamina + "%  |  Pressure " + ClientState.pressure + "%"), x, y + 12, 0xE0E0E0);
        context.drawTextWithShadow(text, Text.literal("Mission " + String.format("%02d", ClientState.missionIndex + 1) + ": " + ClientState.missionTitle), x, y + 24, 0xFFFFFF);
        context.drawTextWithShadow(text, Text.literal(ClientState.missionDescription), x, y + 36, 0xB0E0FF);

        // Minimap
        int mapSize = 72;
        int mx = width - mapSize - 12;
        int my = 12;
        context.fill(mx - 2, my - 2, mx + mapSize + 2, my + mapSize + 2, 0xAA101010);
        context.fill(mx, my, mx + mapSize, my + mapSize, 0xFF1A2A1A);

        Vec3d pos = client.player.getPos();
        drawMarker(context, mx, my, mapSize, pos, Landmarks.PIER, 0xFFFFD34D);
        drawMarker(context, mx, my, mapSize, pos, Landmarks.ABANDONED_HOUSE, 0xFFFF5555);
        drawMarker(context, mx, my, mapSize, pos, Landmarks.SAFE_HOUSE, 0xFF55FF55);
        drawMarker(context, mx, my, mapSize, pos, Landmarks.LABORATORY, 0xFF55AAFF);
        drawMarker(context, mx, my, mapSize, pos, Landmarks.HELICOPTER_SITE, 0xFFFFFFFF);
        drawMarker(context, mx, my, mapSize, pos, Landmarks.BOSS_ARENA, 0xFFFF00FF);

        // Player dot
        context.fill(mx + mapSize / 2 - 2, my + mapSize / 2 - 2, mx + mapSize / 2 + 2, my + mapSize / 2 + 2, 0xFFFFFFFF);

        // Inventory overlay
        int iy = height - 48;
        context.fill(8, iy - 4, 220, iy + 40, 0x88000000);
        context.drawTextWithShadow(text, Text.literal("Survival Kit").formatted(Formatting.GREEN), 12, iy, 0xFFFFFF);
        context.drawTextWithShadow(text, Text.literal("Bandage: " + client.player.getInventory().count(com.veilborn.island.registry.ModItems.BANDAGE)), 12, iy + 12, 0xFFFFFF);
        context.drawTextWithShadow(text, Text.literal("Food: " + client.player.getInventory().count(com.veilborn.island.registry.ModItems.COCONUT) + " / " + client.player.getInventory().count(com.veilborn.island.registry.ModItems.BERRY) + " / " + client.player.getInventory().count(com.veilborn.island.registry.ModItems.ANIMAL_MEAT)), 12, iy + 24, 0xFFFFFF);

        if (ClientState.introRunning) {
            context.fill(0, 0, width, height, 0xCC000000);
            context.drawCenteredTextWithShadow(text, Text.literal("Survival is not an option.").formatted(Formatting.WHITE), width / 2, height / 2 - 6, 0xFFFFFF);
            context.drawCenteredTextWithShadow(text, Text.literal("It’s a necessity.").formatted(Formatting.GRAY), width / 2, height / 2 + 8, 0xFFFFFF);
        }

        if (ClientState.endingRunning) {
            context.fill(0, 0, width, height, 0xCC000000);
            context.drawCenteredTextWithShadow(text, Text.literal("ESCAPE").formatted(Formatting.GOLD), width / 2, height / 2 - 8, 0xFFFFFF);
            context.drawCenteredTextWithShadow(text, Text.literal("Credits are rolling..."), width / 2, height / 2 + 6, 0xFFFFFF);
        }
    }

    private static void drawMarker(DrawContext context, int x, int y, int size, Vec3d playerPos, BlockPos marker, int color) {
        double dx = marker.getX() - playerPos.x;
        double dz = marker.getZ() - playerPos.z;
        double scale = 1.0 / 8.0;
        int px = MathHelper.clamp(x + size / 2 + (int) Math.round(dx * scale), x + 2, x + size - 3);
        int py = MathHelper.clamp(y + size / 2 + (int) Math.round(dz * scale), y + 2, y + size - 3);
        context.fill(px - 1, py - 1, px + 1, py + 1, color);
    }
}
