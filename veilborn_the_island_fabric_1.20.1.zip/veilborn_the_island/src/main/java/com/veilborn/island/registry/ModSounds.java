package com.veilborn.island.registry;

import com.veilborn.island.VeilbornMod;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public final class ModSounds {
    private ModSounds() {}

    public static final SoundEvent AMBIENT_FOREST = register("ambient.forest");
    public static final SoundEvent AMBIENT_WIND = register("ambient.wind");
    public static final SoundEvent AMBIENT_FOG = register("ambient.fog");
    public static final SoundEvent AMBIENT_LAB = register("ambient.lab");
    public static final SoundEvent ZOMBIE_SCREAM = register("entity.zombie_scream");
    public static final SoundEvent BOSS_MUSIC = register("music.boss");
    public static final SoundEvent LAB_MUSIC = register("music.lab");
    public static final SoundEvent QUEST_COMPLETE = register("ui.quest_complete");

    public static void register() {
    }

    private static SoundEvent register(String path) {
        Identifier id = new Identifier(VeilbornMod.MOD_ID, path);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }
}
