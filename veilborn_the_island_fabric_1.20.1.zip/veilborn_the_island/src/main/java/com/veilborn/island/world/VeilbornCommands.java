package com.veilborn.island.world;

import com.mojang.brigadier.CommandDispatcher;
import com.veilborn.island.VeilbornState;
import com.veilborn.island.gameplay.CutsceneManager;
import com.veilborn.island.gameplay.MissionManager;
import com.veilborn.island.gameplay.EndingManager;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.item.ItemStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public final class VeilbornCommands {
    private VeilbornCommands() {}

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("veilborn")
                .requires(source -> source.hasPermissionLevel(2))
                .then(CommandManager.literal("skipintro").executes(context -> {
                    ServerPlayerEntity player = context.getSource().getPlayerOrThrow();
                    VeilbornState state = VeilbornState.get(player.getServerWorld());
                    CutsceneManager.skipIntro(player, state);
                    return 1;
                }))
                .then(CommandManager.literal("completeall").executes(context -> {
                    ServerPlayerEntity player = context.getSource().getPlayerOrThrow();
                    VeilbornState state = VeilbornState.get(player.getServerWorld());
                    MissionManager.completeAll(player, state);
                    return 1;
                }))
                .then(CommandManager.literal("boss").executes(context -> {
                    ServerPlayerEntity player = context.getSource().getPlayerOrThrow();
                    VeilbornState state = VeilbornState.get(player.getServerWorld());
                    EndingManager.spawnBoss(player.getServerWorld(), state);
                    return 1;
                }))
        );
    }
}
