package com.veilborn.island;

import net.minecraft.nbt.NbtCompound;

public class PlayerProfile {
    public int missionIndex = 0;
    public int missionProgress = 0;
    public int stamina = 100;
    public int pressure = 0;
    public int daysSurvived = 0;
    public boolean introSeen = false;
    public boolean creditsSeen = false;

    public double lastX = 0.0;
    public double lastY = 0.0;
    public double lastZ = 0.0;
    public boolean hasLastPosition = false;

    public long lastSyncTick = 0L;
    public boolean dirty = true;

    public NbtCompound toNbt() {
        NbtCompound nbt = new NbtCompound();
        nbt.putInt("MissionIndex", missionIndex);
        nbt.putInt("MissionProgress", missionProgress);
        nbt.putInt("Stamina", stamina);
        nbt.putInt("Pressure", pressure);
        nbt.putInt("DaysSurvived", daysSurvived);
        nbt.putBoolean("IntroSeen", introSeen);
        nbt.putBoolean("CreditsSeen", creditsSeen);
        nbt.putDouble("LastX", lastX);
        nbt.putDouble("LastY", lastY);
        nbt.putDouble("LastZ", lastZ);
        nbt.putBoolean("HasLastPosition", hasLastPosition);
        return nbt;
    }

    public static PlayerProfile fromNbt(NbtCompound nbt) {
        PlayerProfile profile = new PlayerProfile();
        profile.missionIndex = nbt.getInt("MissionIndex");
        profile.missionProgress = nbt.getInt("MissionProgress");
        profile.stamina = nbt.getInt("Stamina");
        profile.pressure = nbt.getInt("Pressure");
        profile.daysSurvived = nbt.getInt("DaysSurvived");
        profile.introSeen = nbt.getBoolean("IntroSeen");
        profile.creditsSeen = nbt.getBoolean("CreditsSeen");
        profile.lastX = nbt.getDouble("LastX");
        profile.lastY = nbt.getDouble("LastY");
        profile.lastZ = nbt.getDouble("LastZ");
        profile.hasLastPosition = nbt.getBoolean("HasLastPosition");
        return profile;
    }
}
