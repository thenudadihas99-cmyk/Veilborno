package com.veilborn.island;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.PersistentState;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class VeilbornState extends PersistentState {
    private final Map<UUID, PlayerProfile> profiles = new HashMap<>();
    public boolean bossSpawned = false;
    public boolean bossDefeated = false;
    public boolean endingStarted = false;
    public long lastHordeDay = -1L;
    public boolean islandGenerated = false;
    public long worldDayCounter = 0L;

    public static VeilbornState createFromNbt(NbtCompound nbt) {
        VeilbornState state = new VeilbornState();
        state.bossSpawned = nbt.getBoolean("BossSpawned");
        state.bossDefeated = nbt.getBoolean("BossDefeated");
        state.endingStarted = nbt.getBoolean("EndingStarted");
        state.lastHordeDay = nbt.getLong("LastHordeDay");
        state.islandGenerated = nbt.getBoolean("IslandGenerated");
        state.worldDayCounter = nbt.getLong("WorldDayCounter");

        NbtCompound players = nbt.getCompound("Players");
        for (String key : players.getKeys()) {
            try {
                UUID uuid = UUID.fromString(key);
                state.profiles.put(uuid, PlayerProfile.fromNbt(players.getCompound(key)));
            } catch (IllegalArgumentException ignored) {
            }
        }
        return state;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        nbt.putBoolean("BossSpawned", bossSpawned);
        nbt.putBoolean("BossDefeated", bossDefeated);
        nbt.putBoolean("EndingStarted", endingStarted);
        nbt.putLong("LastHordeDay", lastHordeDay);
        nbt.putBoolean("IslandGenerated", islandGenerated);
        nbt.putLong("WorldDayCounter", worldDayCounter);

        NbtCompound players = new NbtCompound();
        for (Map.Entry<UUID, PlayerProfile> entry : profiles.entrySet()) {
            players.put(entry.getKey().toString(), entry.getValue().toNbt());
        }
        nbt.put("Players", players);
        return nbt;
    }

    public PlayerProfile getProfile(UUID uuid) {
        return profiles.computeIfAbsent(uuid, ignored -> new PlayerProfile());
    }

    public static VeilbornState get(ServerWorld world) {
        return world.getPersistentStateManager().getOrCreate(VeilbornState::createFromNbt, VeilbornState::new, VeilbornMod.MOD_ID + "_state");
    }
}
