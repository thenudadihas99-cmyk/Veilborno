package com.veilborn.island.client;

public final class ClientState {
    private ClientState() {}

    public static String missionTitle = "";
    public static String missionDescription = "";
    public static int missionIndex = 0;
    public static int missionProgress = 0;
    public static int missionGoal = 1;
    public static int stamina = 100;
    public static int pressure = 0;
    public static int day = 1;
    public static boolean introRunning = false;
    public static boolean forceFirstPerson = true;
    public static boolean endingRunning = false;
}
