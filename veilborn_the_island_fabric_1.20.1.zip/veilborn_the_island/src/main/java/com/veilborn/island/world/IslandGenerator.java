package com.veilborn.island.world;

import com.veilborn.island.Landmarks;
import com.veilborn.island.VeilbornMod;
import com.veilborn.island.VeilbornState;
import com.veilborn.island.entity.AntEntity;
import com.veilborn.island.entity.GiantZombieEntity;
import com.veilborn.island.entity.ShadowSpiderEntity;
import com.veilborn.island.entity.VeilZombieEntity;
import com.veilborn.island.registry.ModBlocks;
import com.veilborn.island.registry.ModEntities;
import com.veilborn.island.registry.ModItems;
import com.veilborn.island.registry.ModSounds;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.ConfiguredFeature;
import net.minecraft.world.gen.feature.DefaultFeatureConfig;


public final class IslandGenerator {
    private IslandGenerator() {}

    public static final int SEA_LEVEL = 63;
    public static final int RADIUS = 180;

    public static void bootstrap(MinecraftServer server) {
        ServerWorld world = server.getOverworld();
        ensureBootstrap(world);
    }

    public static void ensureBootstrap(ServerWorld world) {
        VeilbornState state = VeilbornState.get(world);
        if (state.islandGenerated) return;

        BlockPos center = BlockPos.ORIGIN;
        for (int x = -RADIUS - 32; x <= RADIUS + 32; x++) {
            for (int z = -RADIUS - 32; z <= RADIUS + 32; z++) {
                double dist = Math.sqrt(x * x + z * z);
                if (dist > RADIUS + 32) continue;
                int surface = getSurfaceHeight(x, z);
                placeTerrainColumn(world, x, z, surface, dist);
            }
        }

        buildLandmarks(world);
        state.islandGenerated = true;
        state.markDirty();
    }

    public static int getSurfaceHeight(int x, int z) {
        double radial = Math.max(0.0, 1.0 - (Math.sqrt(x * x + z * z) / (double) RADIUS));
        double hills = Math.sin(x * 0.045) * 6.0 + Math.cos(z * 0.04) * 5.0 + Math.sin((x + z) * 0.02) * 3.0;
        double coast = radial * 18.0;
        return (int) MathHelper.clamp(SEA_LEVEL + coast + hills, SEA_LEVEL - 5, SEA_LEVEL + 36);
    }

    private static void placeTerrainColumn(ServerWorld world, int x, int z, int surface, double dist) {
        for (int y = 0; y <= surface; y++) {
            BlockState state;
            if (y < surface - 5) {
                state = Blocks.STONE.getDefaultState();
            } else if (y < surface - 1) {
                state = Blocks.DIRT.getDefaultState();
            } else {
                if (dist > RADIUS - 16) {
                    state = Blocks.SAND.getDefaultState();
                } else if (surface < SEA_LEVEL + 1) {
                    state = Blocks.GRAVEL.getDefaultState();
                } else {
                    state = Blocks.GRASS_BLOCK.getDefaultState();
                }
            }
            world.setBlockState(new BlockPos(x, y, z), state, Block.NOTIFY_LISTENERS);
        }
        for (int y = surface + 1; y <= SEA_LEVEL; y++) {
            world.setBlockState(new BlockPos(x, y, z), Blocks.WATER.getDefaultState(), Block.NOTIFY_LISTENERS);
        }
    }

    private static void flattenArea(ServerWorld world, BlockPos center, int radius, int height) {
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                int wx = center.getX() + x;
                int wz = center.getZ() + z;
                int ground = height + (int) (Math.sin((wx + wz) * 0.03) * 1.0);
                for (int y = 0; y <= ground; y++) {
                    BlockState state = y < ground - 4 ? Blocks.DIRT.getDefaultState() : Blocks.GRASS_BLOCK.getDefaultState();
                    if (y < SEA_LEVEL - 2) state = Blocks.STONE.getDefaultState();
                    world.setBlockState(new BlockPos(wx, y, wz), state, Block.NOTIFY_LISTENERS);
                }
                for (int y = ground + 1; y <= SEA_LEVEL; y++) {
                    world.setBlockState(new BlockPos(wx, y, wz), Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                }
            }
        }
    }

    private static void buildLandmarks(ServerWorld world) {
        buildPier(world, Landmarks.PIER);
        buildSafeHouse(world, Landmarks.SAFE_HOUSE);
        buildAbandonedHouse(world, Landmarks.ABANDONED_HOUSE);
        buildLaboratory(world, Landmarks.LABORATORY);
        buildWatchTower(world, Landmarks.WATCH_TOWER_NORTH);
        buildWatchTower(world, Landmarks.WATCH_TOWER_SOUTH);
        buildWatchTower(world, Landmarks.WATCH_TOWER_EAST);
        buildWatchTower(world, Landmarks.WATCH_TOWER_WEST);
        buildShipwreck(world, Landmarks.SHIPWRECK);
        buildHelicopterCrashSite(world, Landmarks.HELICOPTER_SITE);
        buildZombieCamp(world, Landmarks.ZOMBIE_CAMP);
        buildSecretCave(world, Landmarks.SECRET_CAVE);
    }

    private static void buildPier(ServerWorld world, BlockPos pos) {
        flattenArea(world, pos, 6, SEA_LEVEL);
        for (int i = 0; i < 18; i++) {
            set(world, pos.add(i, 0, 0), Blocks.OAK_PLANKS);
            set(world, pos.add(i, -1, 0), Blocks.OAK_FENCE);
            if (i % 4 == 0) set(world, pos.add(i, 1, 0), Blocks.TORCH);
        }
        for (int z = -2; z <= 2; z++) {
            set(world, pos.add(0, 0, z), Blocks.OAK_PLANKS);
            set(world, pos.add(2, 0, z), Blocks.OAK_PLANKS);
        }
        placeChest(world, pos.add(4, 1, 1), new ItemStack[]{
                new ItemStack(ModItems.COCONUT, 6),
                new ItemStack(ModItems.BERRY, 4),
                new ItemStack(ModItems.BANDAGE, 2)
        });
    }

    private static void buildSafeHouse(ServerWorld world, BlockPos pos) {
        flattenArea(world, pos, 7, SEA_LEVEL + 1);
        for (int x = -3; x <= 3; x++) {
            for (int z = -3; z <= 3; z++) {
                if (Math.abs(x) == 3 || Math.abs(z) == 3) {
                    for (int y = 0; y <= 4; y++) set(world, pos.add(x, y, z), Blocks.SPRUCE_PLANKS);
                }
            }
        }
        for (int x = -2; x <= 2; x++) {
            for (int z = -2; z <= 2; z++) {
                set(world, pos.add(x, 5, z), Blocks.SPRUCE_SLAB);
            }
        }
        set(world, pos.add(0, 1, 0), Blocks.CRAFTING_TABLE);
        set(world, pos.add(1, 1, 0), Blocks.RED_BED);
        set(world, pos.add(-1, 1, 0), Blocks.LANTERN);
        placeChest(world, pos.add(2, 1, 2), new ItemStack[]{
                new ItemStack(ModItems.ISLAND_MAP, 1),
                new ItemStack(ModItems.BANDAGE, 3),
                new ItemStack(ModItems.WOOD, 12),
                new ItemStack(ModItems.STICK, 12)
        });
    }

    private static void buildAbandonedHouse(ServerWorld world, BlockPos pos) {
        flattenArea(world, pos, 6, SEA_LEVEL + 1);
        for (int x = -2; x <= 2; x++) {
            for (int z = -2; z <= 2; z++) {
                if (Math.abs(x) == 2 || Math.abs(z) == 2) {
                    for (int y = 0; y <= 3; y++) set(world, pos.add(x, y, z), Blocks.OAK_PLANKS);
                }
            }
        }
        set(world, pos.add(0, 4, 0), Blocks.AIR);
        set(world, pos.add(-1, 1, 0), Blocks.COBWEB);
        set(world, pos.add(1, 1, 0), Blocks.COBWEB);
        placeChest(world, pos.add(0, 1, 2), new ItemStack[]{
                new ItemStack(ModItems.CLOTH, 4),
                new ItemStack(ModItems.STRING, 6),
                new ItemStack(ModItems.WOOD, 6)
        });
    }

    private static void buildLaboratory(ServerWorld world, BlockPos pos) {
        flattenArea(world, pos, 10, SEA_LEVEL + 2);
        for (int x = -5; x <= 5; x++) {
            for (int z = -4; z <= 4; z++) {
                if (Math.abs(x) == 5 || Math.abs(z) == 4) {
                    for (int y = 0; y <= 5; y++) set(world, pos.add(x, y, z), Blocks.GRAY_CONCRETE);
                }
            }
        }
        for (int x = -4; x <= 4; x++) {
            for (int z = -3; z <= 3; z++) {
                if (x == -4 || x == 4 || z == -3 || z == 3) {
                    set(world, pos.add(x, 6, z), Blocks.LIGHT_GRAY_STAINED_GLASS);
                }
            }
        }
        set(world, pos.add(0, 1, 0), ModBlocks.LAB_PANEL);
        set(world, pos.add(1, 1, 0), Blocks.COMPOSTER);
        set(world, pos.add(-1, 1, 0), Blocks.LECTERN);
        placeChest(world, pos.add(2, 1, 2), new ItemStack[]{
                new ItemStack(ModItems.ANCIENT_CRYSTAL, 2),
                new ItemStack(ModItems.OIL, 6),
                new ItemStack(ModItems.IRON, 8)
        });
    }

    private static void buildWatchTower(ServerWorld world, BlockPos pos) {
        flattenArea(world, pos, 4, SEA_LEVEL + 5);
        for (int y = 0; y <= 12; y++) {
            set(world, pos.add(0, y, 0), Blocks.SPRUCE_LOG);
            set(world, pos.add(1, y, 0), Blocks.SPRUCE_LOG);
            set(world, pos.add(0, y, 1), Blocks.SPRUCE_LOG);
            set(world, pos.add(1, y, 1), Blocks.SPRUCE_LOG);
        }
        for (int x = -1; x <= 2; x++) for (int z = -1; z <= 2; z++) set(world, pos.add(x, 13, z), Blocks.SPRUCE_PLANKS);
        set(world, pos.add(0, 14, 0), Blocks.LANTERN);
    }

    private static void buildShipwreck(ServerWorld world, BlockPos pos) {
        flattenArea(world, pos, 8, SEA_LEVEL);
        for (int i = 0; i < 12; i++) {
            set(world, pos.add(i - 3, 0, 0), Blocks.SPRUCE_PLANKS);
            if (i < 9) set(world, pos.add(i - 3, 1, 1), Blocks.OAK_PLANKS);
        }
        set(world, pos.add(1, 1, -1), Blocks.COBWEB);
        set(world, pos.add(2, 1, -1), Blocks.COBWEB);
        placeChest(world, pos.add(0, 1, 2), new ItemStack[]{
                new ItemStack(ModItems.LEATHER, 4),
                new ItemStack(ModItems.STRING, 8),
                new ItemStack(ModItems.BANDAGE, 1)
        });
    }

    private static void buildHelicopterCrashSite(ServerWorld world, BlockPos pos) {
        flattenArea(world, pos, 8, SEA_LEVEL + 1);
        for (int x = -3; x <= 4; x++) {
            for (int z = -1; z <= 1; z++) {
                set(world, pos.add(x, 2, z), Blocks.IRON_BLOCK);
            }
        }
        for (int x = -2; x <= 3; x++) {
            set(world, pos.add(x, 3, 0), Blocks.RED_WOOL);
        }
        set(world, pos.add(4, 3, 0), Blocks.BEACON);
        set(world, pos.add(-3, 1, 0), ModBlocks.HELICOPTER_CONSOLE);
        placeChest(world, pos.add(2, 1, 2), new ItemStack[]{
                new ItemStack(ModItems.OIL, 4),
                new ItemStack(ModItems.IRON, 5),
                new ItemStack(ModItems.CLOTH, 3)
        });
    }

    private static void buildZombieCamp(ServerWorld world, BlockPos pos) {
        flattenArea(world, pos, 7, SEA_LEVEL + 1);
        for (int x = -3; x <= 3; x++) {
            for (int z = -3; z <= 3; z++) {
                if (Math.abs(x) == 3 || Math.abs(z) == 3) {
                    set(world, pos.add(x, 0, z), Blocks.DARK_OAK_PLANKS);
                    set(world, pos.add(x, 1, z), Blocks.BROWN_WOOL);
                }
            }
        }
        set(world, pos.add(0, 1, 0), Blocks.CAMPFIRE);
        placeChest(world, pos.add(-1, 1, 2), new ItemStack[]{
                new ItemStack(ModItems.CLOTH, 6),
                new ItemStack(ModItems.OIL, 3),
                new ItemStack(ModItems.STRING, 4)
        });
    }

    private static void buildSecretCave(ServerWorld world, BlockPos pos) {
        for (int x = -6; x <= 6; x++) {
            for (int z = -6; z <= 6; z++) {
                for (int y = -3; y <= 4; y++) {
                    BlockPos p = pos.add(x, y, z);
                    if (x * x + z * z + y * y < 36) {
                        world.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                    } else if (y <= 0) {
                        world.setBlockState(p, Blocks.STONE.getDefaultState(), Block.NOTIFY_LISTENERS);
                    }
                }
            }
        }
        set(world, pos.add(0, 0, 0), Blocks.AMETHYST_BLOCK);
        set(world, pos.add(1, 0, 0), Blocks.AMETHYST_BLOCK);
        set(world, pos.add(0, 1, 0), Blocks.AMETHYST_CLUSTER);
        placeChest(world, pos.add(2, 0, 2), new ItemStack[]{
                new ItemStack(ModItems.ANCIENT_CRYSTAL, 1),
                new ItemStack(ModItems.MEDICINE_HERBS, 6)
        });
    }

    private static void placeChest(ServerWorld world, BlockPos pos, ItemStack[] stacks) {
        set(world, pos, Blocks.CHEST);
        if (world.getBlockEntity(pos) instanceof ChestBlockEntity chest) {
            for (int i = 0; i < stacks.length && i < chest.size(); i++) {
                chest.setStack(i, stacks[i]);
            }
        }
    }

    private static void set(ServerWorld world, BlockPos pos, Block block) {
        world.setBlockState(pos, block.getDefaultState(), Block.NOTIFY_LISTENERS);
    }

    public static void tickAmbience(ServerWorld world, VeilbornState state) {
        var random = world.random;
        if (random.nextInt(120) != 0) return;
        world.getPlayers().forEach(player -> {
            if (random.nextBoolean()) {
                world.playSound(null, player.getBlockPos(), ModSounds.AMBIENT_WIND, SoundCategory.AMBIENT, 0.8f, 0.9f + random.nextFloat() * 0.2f);
            } else {
                world.playSound(null, player.getBlockPos(), ModSounds.AMBIENT_FOREST, SoundCategory.AMBIENT, 0.8f, 0.9f + random.nextFloat() * 0.2f);
            }
        });
    }

    public static void spawnMidnightHorde(ServerWorld world, VeilbornState state) {
        if (state.lastHordeDay == state.worldDayCounter) return;
        state.lastHordeDay = state.worldDayCounter;
        state.markDirty();
        for (var player : world.getPlayers()) {
            BlockPos center = player.getBlockPos();
            for (int i = 0; i < 8; i++) {
                VeilZombieEntity zombie = ModEntities.NORMAL_ZOMBIE.create(world);
                if (zombie != null) {
                    zombie.refreshPositionAndAngles(center.getX() + world.random.nextBetween(-8, 8), center.getY(), center.getZ() + world.random.nextBetween(-8, 8), world.random.nextFloat() * 360.0f, 0.0f);
                    world.spawnEntity(zombie);
                }
            }
            for (int i = 0; i < 2; i++) {
                VeilZombieEntity shadow = ModEntities.SHADOW_ZOMBIE.create(world);
                if (shadow != null) {
                    shadow.refreshPositionAndAngles(center.getX() + world.random.nextBetween(-12, 12), center.getY(), center.getZ() + world.random.nextBetween(-12, 12), world.random.nextFloat() * 360.0f, 0.0f);
                    world.spawnEntity(shadow);
                }
            }
            AntEntity ant = ModEntities.ANT.create(world);
            if (ant != null) {
                ant.refreshPositionAndAngles(center.getX() + world.random.nextBetween(-6, 6), center.getY(), center.getZ() + world.random.nextBetween(-6, 6), 0.0f, 0.0f);
                world.spawnEntity(ant);
            }
            if (world.random.nextBoolean()) {
                ShadowSpiderEntity spider = ModEntities.SHADOW_SPIDER.create(world);
                if (spider != null) {
                    spider.refreshPositionAndAngles(center.getX() + world.random.nextBetween(-14, 14), center.getY(), center.getZ() + world.random.nextBetween(-14, 14), 0.0f, 0.0f);
                    world.spawnEntity(spider);
                }
            }
            world.playSound(null, center, ModSounds.ZOMBIE_SCREAM, SoundCategory.HOSTILE, 1.0f, 0.6f);
        }
    }
}
