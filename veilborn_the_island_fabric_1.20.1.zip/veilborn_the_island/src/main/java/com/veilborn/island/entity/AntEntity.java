package com.veilborn.island.entity;

import com.veilborn.island.registry.ModItems;
import com.veilborn.island.registry.ModSounds;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.GoalSelector;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.SilverfishEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.world.World;

public class AntEntity extends SilverfishEntity {
    public AntEntity(EntityType<? extends SilverfishEntity> entityType, World world) {
        super(entityType, world);
    }

    public static DefaultAttributeContainer.Builder createAntAttributes() {
        return SilverfishEntity.createSilverfishAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 10.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.42)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 4.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.55, true));
        this.goalSelector.add(7, new net.minecraft.entity.ai.goal.WanderAroundFarGoal(this, 1.3));
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, LivingEntity.class, true));
    }

    @Override
    protected void dropEquipment(net.minecraft.entity.damage.DamageSource source, int looting, boolean causedByPlayer) {
        super.dropEquipment(source, looting, causedByPlayer);
        this.dropStack(new ItemStack(ModItems.STRING, 2 + this.random.nextInt(3)));
        if (this.random.nextBoolean()) this.dropStack(new ItemStack(ModItems.CLOTH, 1));
        this.getWorld().playSound(null, this.getBlockPos(), ModSounds.QUEST_COMPLETE, SoundCategory.HOSTILE, 0.5f, 1.8f);
    }
}
