package com.veilborn.island.gameplay;

import com.veilborn.island.PlayerProfile;
import com.veilborn.island.VeilbornMod;
import com.veilborn.island.VeilbornState;
import com.veilborn.island.registry.ModEntities;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityType;
import net.minecraft.item.Item;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public final class MissionManager {
    private MissionManager() {}

    public static void tickWorld(net.minecraft.server.world.ServerWorld world, VeilbornState state) {
        for (ServerPlayerEntity player : world.getPlayers()) {
            PlayerProfile profile = state.getProfile(player.getUuid());

            if (profile.missionIndex >= MissionRegistry.MISSIONS.size()) continue;

            MissionDefinition def = MissionRegistry.mission(profile.missionIndex);
            int progress = Math.max(0, def.progressEvaluator().evaluate(player, state));
            if (progress != profile.missionProgress) {
                profile.missionProgress = progress;
                profile.dirty = true;
            }

            if (progress >= def.goal()) {
                completeMission(player, state, profile.missionIndex, "Mission complete: " + def.title());
            }

            if (!state.bossSpawned && profile.missionIndex >= 46 && !state.bossDefeated) {
                spawnBossIfNeeded(player, state);
            }

            if (profile.dirty && (world.getTimeOfDay() % 20L == 0L)) {
                sync(player, state);
                profile.dirty = false;
            }
        }
    }

    public static void completeMission(ServerPlayerEntity player, VeilbornState state, int missionIndex, String message) {
        PlayerProfile profile = state.getProfile(player.getUuid());
        if (profile.missionIndex != missionIndex || missionIndex >= MissionRegistry.MISSIONS.size()) return;

        MissionDefinition def = MissionRegistry.mission(missionIndex);
        def.reward().apply(player, state);
        player.sendMessage(Text.literal(message).formatted(Formatting.GOLD), false);
        player.getWorld().playSound(null, player.getBlockPos(), com.veilborn.island.registry.ModSounds.QUEST_COMPLETE, net.minecraft.sound.SoundCategory.PLAYERS, 0.95f, 1.0f);

        profile.missionIndex++;
        profile.missionProgress = 0;
        profile.dirty = true;
        sync(player, state);
        state.markDirty();
    }

    public static void completeAll(ServerPlayerEntity player, VeilbornState state) {
        PlayerProfile profile = state.getProfile(player.getUuid());
        while (profile.missionIndex < MissionRegistry.MISSIONS.size()) {
            MissionDefinition def = MissionRegistry.mission(profile.missionIndex);
            def.reward().apply(player, state);
            profile.missionIndex++;
        }
        profile.missionProgress = 0;
        profile.dirty = true;
        sync(player, state);
        state.markDirty();
    }

    public static void sync(ServerPlayerEntity player, VeilbornState state) {
        PlayerProfile profile = state.getProfile(player.getUuid());
        if (profile.missionIndex >= MissionRegistry.MISSIONS.size()) {
            return;
        }
        MissionDefinition def = MissionRegistry.mission(profile.missionIndex);
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(profile.missionIndex);
        buf.writeInt(profile.missionProgress);
        buf.writeInt(def.goal());
        buf.writeString(def.title());
        buf.writeString(def.description());
        buf.writeInt(profile.stamina);
        buf.writeInt(profile.pressure);
        buf.writeInt((int) state.worldDayCounter);
        buf.writeBoolean(CutsceneManager.isIntroRunning(player));
        buf.writeBoolean(EndingManager.isEndingRunning(player));
        ServerPlayNetworking.send(player, VeilbornMod.id("sync_state"), buf);
    }

    public static void spawnBossIfNeeded(ServerPlayerEntity player, VeilbornState state) {
        if (state.bossSpawned) return;
        net.minecraft.server.world.ServerWorld world = player.getServerWorld();
        BlockPos pos = com.veilborn.island.Landmarks.BOSS_ARENA;
        com.veilborn.island.entity.GiantZombieEntity boss = ModEntities.GIANT_ZOMBIE.create(world);
        if (boss != null) {
            boss.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, 180.0f, 0.0f);
            world.spawnEntity(boss);
            state.bossSpawned = true;
            state.markDirty();
            player.sendMessage(Text.literal("The Giant Zombie has awakened.").formatted(Formatting.DARK_RED), false);
        }
    }

    public static void onBossDefeated(net.minecraft.server.world.ServerWorld world, VeilbornState state) {
        state.bossDefeated = true;
        state.markDirty();
        for (ServerPlayerEntity player : world.getPlayers()) {
            PlayerProfile profile = state.getProfile(player.getUuid());
            if (profile.missionIndex == 47) {
                completeMission(player, state, 47, "The Giant Zombie has fallen.");
            }
        }
    }
}
