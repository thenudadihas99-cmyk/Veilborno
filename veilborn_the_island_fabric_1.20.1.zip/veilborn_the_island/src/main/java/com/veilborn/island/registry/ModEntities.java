package com.veilborn.island.registry;

import com.veilborn.island.VeilbornMod;
import com.veilborn.island.entity.AntEntity;
import com.veilborn.island.entity.GiantZombieEntity;
import com.veilborn.island.entity.ShadowSpiderEntity;
import com.veilborn.island.entity.VeilZombieEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModEntities {
    private ModEntities() {}

    public static final EntityType<AntEntity> ANT = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(VeilbornMod.MOD_ID, "ant"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, AntEntity::new)
                    .dimensions(EntityDimensions.fixed(0.45f, 0.28f))
                    .trackRangeBlocks(48)
                    .trackedUpdateRate(3)
                    .build()
    );

    public static final EntityType<VeilZombieEntity> NORMAL_ZOMBIE = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(VeilbornMod.MOD_ID, "normal_zombie"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, VeilZombieEntity::new)
                    .dimensions(EntityDimensions.fixed(0.6f, 1.95f))
                    .trackRangeBlocks(64)
                    .trackedUpdateRate(3)
                    .build()
    );

    public static final EntityType<VeilZombieEntity> SHADOW_ZOMBIE = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(VeilbornMod.MOD_ID, "shadow_zombie"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, VeilZombieEntity::new)
                    .dimensions(EntityDimensions.fixed(0.6f, 1.95f))
                    .trackRangeBlocks(64)
                    .trackedUpdateRate(3)
                    .build()
    );

    public static final EntityType<ShadowSpiderEntity> SHADOW_SPIDER = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(VeilbornMod.MOD_ID, "shadow_spider"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, ShadowSpiderEntity::new)
                    .dimensions(EntityDimensions.fixed(1.4f, 0.9f))
                    .trackRangeBlocks(64)
                    .trackedUpdateRate(3)
                    .build()
    );

    public static final EntityType<GiantZombieEntity> GIANT_ZOMBIE = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(VeilbornMod.MOD_ID, "giant_zombie"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, GiantZombieEntity::new)
                    .dimensions(EntityDimensions.fixed(2.4f, 6.0f))
                    .trackRangeBlocks(128)
                    .trackedUpdateRate(3)
                    .build()
    );

    public static void register() {
        FabricDefaultAttributeRegistry.register(ANT, AntEntity.createAntAttributes());
        FabricDefaultAttributeRegistry.register(NORMAL_ZOMBIE, VeilZombieEntity.createNormalAttributes());
        FabricDefaultAttributeRegistry.register(SHADOW_ZOMBIE, VeilZombieEntity.createShadowAttributes());
        FabricDefaultAttributeRegistry.register(SHADOW_SPIDER, ShadowSpiderEntity.createSpiderAttributes());
        FabricDefaultAttributeRegistry.register(GIANT_ZOMBIE, GiantZombieEntity.createBossAttributes());
    }
}
