package com.veilborn.island.entity;

import com.veilborn.island.registry.ModItems;
import com.veilborn.island.registry.ModSounds;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.world.World;

public class ShadowSpiderEntity extends SpiderEntity {
    public ShadowSpiderEntity(EntityType<? extends SpiderEntity> entityType, World world) {
        super(entityType, world);
    }

    public static DefaultAttributeContainer.Builder createSpiderAttributes() {
        return SpiderEntity.createSpiderAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 250.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.38)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 30.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 55.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.3, true));
        this.goalSelector.add(6, new net.minecraft.entity.ai.goal.WanderAroundFarGoal(this, 1.1));
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, LivingEntity.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.getWorld().isClient && this.getWorld().isNight() && this.age % 30 == 0) {
            this.getWorld().playSound(null, this.getBlockPos(), ModSounds.ZOMBIE_SCREAM, SoundCategory.HOSTILE, 0.45f, 0.5f);
        }
    }

    @Override
    protected void dropEquipment(net.minecraft.entity.damage.DamageSource source, int looting, boolean causedByPlayer) {
        super.dropEquipment(source, looting, causedByPlayer);
        this.dropStack(new ItemStack(ModItems.STRING, 20));
    }
}
