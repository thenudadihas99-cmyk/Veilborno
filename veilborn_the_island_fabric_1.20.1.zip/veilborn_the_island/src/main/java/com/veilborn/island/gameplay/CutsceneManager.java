package com.veilborn.island.gameplay;

import com.veilborn.island.PlayerProfile;
import com.veilborn.island.VeilbornState;
import com.veilborn.island.client.ClientState;
import com.veilborn.island.registry.ModSounds;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.GameMode;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

public final class CutsceneManager {
    private CutsceneManager() {}

    private static final Map<UUID, Integer> INTRO_TICKS = new HashMap<>();

    public static void startIntro(ServerPlayerEntity player, VeilbornState state) {
        PlayerProfile profile = state.getProfile(player.getUuid());
        if (profile.introSeen) return;
        profile.introSeen = true;
        profile.dirty = true;
        INTRO_TICKS.put(player.getUuid(), 0);
        player.changeGameMode(GameMode.SPECTATOR);
        player.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(net.minecraft.entity.effect.StatusEffects.DARKNESS, 800, 0, false, false, true));
        player.teleport(player.getServerWorld(), com.veilborn.island.Landmarks.HELICOPTER_SITE.getX() + 0.5, com.veilborn.island.Landmarks.HELICOPTER_SITE.getY() + 14.0, com.veilborn.island.Landmarks.HELICOPTER_SITE.getZ() + 0.5, player.getYaw(), 0.0f);
        player.sendMessage(Text.literal("Helicopter approaching Veilborn...").formatted(Formatting.GRAY), false);
        player.getWorld().playSound(null, player.getBlockPos(), ModSounds.AMBIENT_WIND, net.minecraft.sound.SoundCategory.AMBIENT, 1.0f, 0.8f);
        MissionManager.sync(player, state);
        state.markDirty();
    }

    public static boolean isIntroRunning(ServerPlayerEntity player) {
        return INTRO_TICKS.containsKey(player.getUuid());
    }

    public static void skipIntro(ServerPlayerEntity player, VeilbornState state) {
        INTRO_TICKS.remove(player.getUuid());
        player.changeGameMode(GameMode.SURVIVAL);
        player.teleport(player.getServerWorld(), com.veilborn.island.Landmarks.SAFE_HOUSE.getX() + 0.5, com.veilborn.island.Landmarks.SAFE_HOUSE.getY() + 2.0, com.veilborn.island.Landmarks.SAFE_HOUSE.getZ() + 0.5, player.getYaw(), 0.0f);
        player.sendMessage(Text.literal("Intro skipped.").formatted(Formatting.YELLOW), false);
        MissionManager.sync(player, state);
        state.markDirty();
    }

    public static void tickWorld(net.minecraft.server.world.ServerWorld world, VeilbornState state) {
        Iterator<Map.Entry<UUID, Integer>> iterator = INTRO_TICKS.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Integer> entry = iterator.next();
            ServerPlayerEntity player = world.getServer().getPlayerManager().getPlayer(entry.getKey());
            if (player == null) {
                iterator.remove();
                continue;
            }
            int tick = entry.getValue() + 1;
            entry.setValue(tick);

            if (tick == 1) {
                player.sendMessage(Text.literal("[0:00] The helicopter skims the island canopy.").formatted(Formatting.DARK_AQUA), false);
                player.teleport(world, com.veilborn.island.Landmarks.HELICOPTER_SITE.getX() + 0.5, com.veilborn.island.Landmarks.HELICOPTER_SITE.getY() + 18.0, com.veilborn.island.Landmarks.HELICOPTER_SITE.getZ() - 20.5, 180.0f, 12.0f);
            } else if (tick == 200) {
                player.sendMessage(Text.literal("[0:10] Fog rolls over waterfalls and the treeline.").formatted(Formatting.GRAY), false);
                player.teleport(world, com.veilborn.island.Landmarks.LABORATORY.getX() - 32.5, com.veilborn.island.Landmarks.LABORATORY.getY() + 18.0, com.veilborn.island.Landmarks.LABORATORY.getZ() + 12.5, 90.0f, 8.0f);
                player.getWorld().playSound(null, player.getBlockPos(), ModSounds.AMBIENT_FOG, net.minecraft.sound.SoundCategory.AMBIENT, 1.0f, 0.7f);
            } else if (tick == 400) {
                player.sendMessage(Text.literal("[0:20] An abandoned house emerges from the mist.").formatted(Formatting.GRAY), false);
                player.teleport(world, com.veilborn.island.Landmarks.ABANDONED_HOUSE.getX() + 0.5, com.veilborn.island.Landmarks.ABANDONED_HOUSE.getY() + 8.0, com.veilborn.island.Landmarks.ABANDONED_HOUSE.getZ() - 12.5, 0.0f, 12.0f);
            } else if (tick == 600) {
                player.sendMessage(Text.literal("[0:30] A zombie scream cuts through the fog.").formatted(Formatting.DARK_RED), false);
                player.getWorld().playSound(null, player.getBlockPos(), ModSounds.ZOMBIE_SCREAM, net.minecraft.sound.SoundCategory.HOSTILE, 2.0f, 0.55f);
            } else if (tick >= 720) {
                player.sendMessage(Text.literal("Survival is not an option. It’s a necessity.").formatted(Formatting.WHITE), false);
                player.changeGameMode(GameMode.SURVIVAL);
                player.teleport(world, com.veilborn.island.Landmarks.SAFE_HOUSE.getX() + 0.5, com.veilborn.island.Landmarks.SAFE_HOUSE.getY() + 2.0, com.veilborn.island.Landmarks.SAFE_HOUSE.getZ() + 0.5, player.getYaw(), 0.0f);
                MissionManager.sync(player, state);
                iterator.remove();
            }
        }
    }
}
