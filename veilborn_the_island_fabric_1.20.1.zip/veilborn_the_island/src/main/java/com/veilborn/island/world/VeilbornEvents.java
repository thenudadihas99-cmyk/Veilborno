package com.veilborn.island.world;

import com.veilborn.island.PlayerProfile;
import com.veilborn.island.VeilbornMod;
import com.veilborn.island.VeilbornState;
import com.veilborn.island.gameplay.CutsceneManager;
import com.veilborn.island.gameplay.EndingManager;
import com.veilborn.island.gameplay.MissionManager;
import com.veilborn.island.gameplay.SurvivalManager;
import com.veilborn.island.gameplay.WorldBorderManager;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameMode;
import net.minecraft.world.World;

public final class VeilbornEvents {
    private VeilbornEvents() {}

    private static long SERVER_TICK_COUNT = 0L;

    public static void register() {
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            IslandGenerator.bootstrap(server);
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity player = handler.player;
            VeilbornState state = VeilbornState.get(player.getServerWorld());
            PlayerProfile profile = state.getProfile(player.getUuid());
            MissionManager.sync(player, state);
            if (!profile.introSeen) {
                CutsceneManager.startIntro(player, state);
            } else {
                player.sendMessage(Text.literal("Return to the island. Survive. Discover. Escape.").formatted(Formatting.GRAY), false);
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(VeilbornEvents::tickServer);

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> VeilbornCommands.register(dispatcher));
    }

    private static void tickServer(MinecraftServer server) {
        SERVER_TICK_COUNT++;
        for (var world : server.getWorlds()) {
            if (world.getRegistryKey() == World.OVERWORLD) {
                IslandGenerator.ensureBootstrap(world);
                VeilbornState state = VeilbornState.get(world);
                long time = world.getTimeOfDay();
                int extra = (int) ((SERVER_TICK_COUNT % 3L) == 0L ? 1 : 0);
                world.setTimeOfDay(time + 1 + extra);
                WorldBorderManager.tickWorld(world, state);
                IslandGenerator.tickAmbience(world, state);
                SurvivalManager.tickWorld(world, state);
                MissionManager.tickWorld(world, state);
                CutsceneManager.tickWorld(world, state);
                EndingManager.tickWorld(world, state);
                if (time % 24000L == 18000L) {
                    IslandGenerator.spawnMidnightHorde(world, state);
                }
            }
        }
    }
}
