package com.veilborn.island.gameplay;

import com.veilborn.island.VeilbornState;
import net.minecraft.server.network.ServerPlayerEntity;

@FunctionalInterface
interface MissionProgressEvaluator {
    int evaluate(ServerPlayerEntity player, VeilbornState state);
}

@FunctionalInterface
interface MissionReward {
    void apply(ServerPlayerEntity player, VeilbornState state);
}

public record MissionDefinition(
        String code,
        String title,
        String description,
        int goal,
        MissionProgressEvaluator progressEvaluator,
        MissionReward reward
) {}
