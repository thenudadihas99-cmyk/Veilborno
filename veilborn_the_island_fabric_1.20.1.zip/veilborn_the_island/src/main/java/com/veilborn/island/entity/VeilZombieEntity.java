package com.veilborn.island.entity;

import com.veilborn.island.registry.ModItems;
import com.veilborn.island.registry.ModSounds;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.world.World;

public class VeilZombieEntity extends ZombieEntity {
    public VeilZombieEntity(EntityType<? extends ZombieEntity> entityType, World world) {
        super(entityType, world);
    }

    public static DefaultAttributeContainer.Builder createNormalAttributes() {
        return ZombieEntity.createZombieAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 100.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.28)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 15.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 40.0);
    }

    public static DefaultAttributeContainer.Builder createShadowAttributes() {
        return ZombieEntity.createZombieAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 200.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.34)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 20.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 50.0);
    }

    public boolean isShadow() {
        return this.getType() == com.veilborn.island.registry.ModEntities.SHADOW_ZOMBIE;
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.1, true));
        this.goalSelector.add(6, new net.minecraft.entity.ai.goal.WanderAroundFarGoal(this, 1.0));
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, LivingEntity.class, true));
        this.targetSelector.add(2, new RevengeGoal(this));
    }

    @Override
    public void tick() {
        super.tick();
        if (this.isShadow() && !this.getWorld().isClient) {
            boolean dark = this.getWorld().isNight() || this.getWorld().getAmbientDarkness() > 6;
            this.setInvisible(dark && this.random.nextInt(40) != 0);
        }
        if (this.age % 300 == 0 && !this.getWorld().isClient) {
            this.getWorld().playSound(null, this.getBlockPos(), ModSounds.ZOMBIE_SCREAM, SoundCategory.HOSTILE, 0.65f, this.isShadow() ? 0.7f : 0.9f);
        }
    }

    @Override
    protected void dropEquipment(net.minecraft.entity.damage.DamageSource source, int looting, boolean causedByPlayer) {
        super.dropEquipment(source, looting, causedByPlayer);
        this.dropStack(new ItemStack(ModItems.STRING, 1 + this.random.nextInt(3)));
        this.dropStack(new ItemStack(ModItems.CLOTH, 1 + this.random.nextInt(2)));
        if (this.isShadow()) {
            this.dropStack(new ItemStack(ModItems.OIL, 1 + this.random.nextInt(2)));
        }
    }
}
