package com.veilborn.island;

import com.veilborn.island.registry.ModBlocks;
import com.veilborn.island.registry.ModEntities;
import com.veilborn.island.registry.ModItems;
import com.veilborn.island.registry.ModSounds;
import com.veilborn.island.world.VeilbornEvents;
import net.fabricmc.api.ModInitializer;

public class VeilbornMod implements ModInitializer {
    public static final String MOD_ID = "veilborn";

    @Override
    public void onInitialize() {
        ModItems.register();
        ModBlocks.register();
        ModEntities.register();
        ModSounds.register();
        VeilbornEvents.register();
    }

    public static net.minecraft.util.Identifier id(String path) {
        return new net.minecraft.util.Identifier(MOD_ID, path);
    }
}
