package com.veilborn.island.client;

import com.veilborn.island.VeilbornMod;
import com.veilborn.island.registry.ModBlocks;
import com.veilborn.island.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;

public class VeilbornClient implements ClientModInitializer {
    public static final Identifier SYNC_PACKET = VeilbornMod.id("sync_state");

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.ANT, context -> new net.minecraft.client.render.entity.SilverfishEntityRenderer(context));
        EntityRendererRegistry.register(ModEntities.NORMAL_ZOMBIE, context -> new net.minecraft.client.render.entity.ZombieEntityRenderer(context));
        EntityRendererRegistry.register(ModEntities.SHADOW_ZOMBIE, context -> new net.minecraft.client.render.entity.ZombieEntityRenderer(context));
        EntityRendererRegistry.register(ModEntities.SHADOW_SPIDER, context -> new net.minecraft.client.render.entity.SpiderEntityRenderer(context));
        EntityRendererRegistry.register(ModEntities.GIANT_ZOMBIE, context -> new net.minecraft.client.render.entity.ZombieEntityRenderer(context));

        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.HELICOPTER_CONSOLE, RenderLayer.getCutout());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.SIGNAL_BEACON, RenderLayer.getCutout());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.LAB_PANEL, RenderLayer.getCutout());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.SUPPLY_CRATE, RenderLayer.getCutout());

        ClientPlayNetworking.registerGlobalReceiver(SYNC_PACKET, (client, handler, buf, responseSender) -> {
            int missionIndex = buf.readInt();
            int missionProgress = buf.readInt();
            int missionGoal = buf.readInt();
            String missionTitle = buf.readString(32767);
            String missionDescription = buf.readString(32767);
            int stamina = buf.readInt();
            int pressure = buf.readInt();
            int day = buf.readInt();
            boolean intro = buf.readBoolean();
            boolean ending = buf.readBoolean();

            client.execute(() -> {
                ClientState.missionIndex = missionIndex;
                ClientState.missionProgress = missionProgress;
                ClientState.missionGoal = missionGoal;
                ClientState.missionTitle = missionTitle;
                ClientState.missionDescription = missionDescription;
                ClientState.stamina = stamina;
                ClientState.pressure = pressure;
                ClientState.day = day;
                ClientState.introRunning = intro;
                ClientState.endingRunning = ending;
            });
        });

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> VeilbornHudRenderer.render(drawContext));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player != null && ClientState.forceFirstPerson && client.options.getPerspective() != Perspective.FIRST_PERSON) {
                client.options.setPerspective(Perspective.FIRST_PERSON);
            }
        });
    }
}
