package com.veilborn.island.gameplay;

import com.veilborn.island.PlayerProfile;
import com.veilborn.island.VeilbornState;
import com.veilborn.island.registry.ModSounds;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.MathHelper;

public final class SurvivalManager {
    private SurvivalManager() {}

    public static void tickWorld(ServerWorld world, VeilbornState state) {
        long currentDay = world.getTimeOfDay() / 24000L + 1;
        if (currentDay > state.worldDayCounter) {
            state.worldDayCounter = currentDay;
            state.markDirty();
        }

        for (ServerPlayerEntity player : world.getPlayers()) {
            PlayerProfile profile = state.getProfile(player.getUuid());
            profile.daysSurvived = (int) Math.max(0L, state.worldDayCounter - 1L);

            double speed = player.getVelocity().horizontalLength();
            int staminaChange = 0;

            if (player.isSprinting() || speed > 0.15) staminaChange -= 2;
            if (player.isTouchingWater()) staminaChange -= 2;
            if (!player.isSprinting() && player.isOnGround()) staminaChange += 1;
            if (nearSafeHouse(player)) staminaChange += 2;

            profile.stamina = MathHelper.clamp(profile.stamina + staminaChange, 0, 100);

            int pressureChange = 0;
            if (world.isNight()) pressureChange += 1;
            if (!nearSafeHouse(player) && world.getAmbientDarkness() > 7) pressureChange += 1;
            if (player.isInSwimmingPose() || player.isSubmergedInWater()) pressureChange += 1;
            if (nearSafeHouse(player) && profile.pressure > 0) pressureChange -= 2;

            profile.pressure = MathHelper.clamp(profile.pressure + pressureChange, 0, 100);

            if (profile.stamina < 20) {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 0, false, false, true));
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 40, 0, false, false, true));
            }

            if (profile.pressure > 70) {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 60, 0, false, false, true));
            }

            if (profile.stamina <= 0) {
                player.damage(player.getDamageSources().generic(), 1.0f);
                profile.stamina = 1;
            }

            if (player.isSprinting() || speed > 0.2) {
                player.getHungerManager().addExhaustion(0.02f);
            }

            if (player.age % 120 == 0) {
                world.playSound(null, player.getBlockPos(), ModSounds.AMBIENT_FOG, SoundCategory.AMBIENT, 0.3f, 0.9f + world.random.nextFloat() * 0.2f);
            }

            profile.dirty = true;
        }
    }

    private static boolean nearSafeHouse(ServerPlayerEntity player) {
        return player.squaredDistanceTo(com.veilborn.island.Landmarks.SAFE_HOUSE.getX() + 0.5, com.veilborn.island.Landmarks.SAFE_HOUSE.getY() + 0.5, com.veilborn.island.Landmarks.SAFE_HOUSE.getZ() + 0.5) <= 24.0 * 24.0;
    }
}
