package com.veilborn.island.registry;

import com.veilborn.island.VeilbornMod;
import com.veilborn.island.block.HelicopterConsoleBlock;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.AbstractBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModBlocks {
    private ModBlocks() {}

    public static final Block HELICOPTER_CONSOLE = registerBlock("helicopter_console",
            new HelicopterConsoleBlock(AbstractBlock.Settings.copy(Blocks.IRON_BLOCK).strength(2.5f).luminance(state -> 4)));
    public static final Block LAB_PANEL = registerBlock("lab_panel",
            new Block(AbstractBlock.Settings.copy(Blocks.IRON_BLOCK).strength(2.0f)));
    public static final Block SIGNAL_BEACON = registerBlock("signal_beacon",
            new Block(AbstractBlock.Settings.copy(Blocks.GLOWSTONE).strength(1.5f).luminance(state -> 10)));
    public static final Block SUPPLY_CRATE = registerBlock("supply_crate",
            new Block(AbstractBlock.Settings.copy(Blocks.OAK_PLANKS).strength(1.5f)));

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL).register(entries -> {
            entries.add(HELICOPTER_CONSOLE.asItem());
            entries.add(LAB_PANEL.asItem());
            entries.add(SIGNAL_BEACON.asItem());
            entries.add(SUPPLY_CRATE.asItem());
        });
    }

    private static Block registerBlock(String path, Block block) {
        Block registered = Registry.register(Registries.BLOCK, new Identifier(VeilbornMod.MOD_ID, path), block);
        Registry.register(Registries.ITEM, new Identifier(VeilbornMod.MOD_ID, path), new BlockItem(registered, new net.minecraft.item.Item.Settings()));
        return registered;
    }
}
